class OverCrowderError(Exception):
    pass